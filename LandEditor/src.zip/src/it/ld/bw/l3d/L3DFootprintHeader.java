package it.ld.bw.l3d;

import it.ld.utils.EndianDataInputStream;
import it.ld.utils.EndianDataOutputStream;
import it.ld.utils.Struct;

public class L3DFootprintHeader extends Struct {
	public int count;
	public int offset;
	public int size;
	public int width;
	public int height;
	public int unknown;
	
	@Override
	public void read(EndianDataInputStream str) throws Exception {
		little(str);
		count = str.readInt();
		offset = str.readInt();
		size = str.readInt();
		width = str.readInt();
		height = str.readInt();
		unknown = str.readInt();
	}
	
	@Override
	public void write(EndianDataOutputStream str) throws Exception {
		throw new RuntimeException("Method not implemented");
	}
}
