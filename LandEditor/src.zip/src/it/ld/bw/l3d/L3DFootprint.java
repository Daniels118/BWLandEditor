package it.ld.bw.l3d;

import it.ld.utils.EndianDataInputStream;
import it.ld.utils.EndianDataOutputStream;
import it.ld.utils.Struct;

public class L3DFootprint extends Struct {
	public L3DFootprintHeader header = new L3DFootprintHeader();
	public L3DFootprintEntry[] entries;
	public L3DFootprintFooter footer = new L3DFootprintFooter();
	
	@Override
	public void read(EndianDataInputStream str) throws Exception {
		header.read(str);
		entries = new L3DFootprintEntry[header.count];
		for (int i = 0; i < header.count; i++) {
			L3DFootprintEntry item = new L3DFootprintEntry(header);
			item.read(str);
			entries[i] = item;
		}
		footer.read(str);
	}

	@Override
	public void write(EndianDataOutputStream str) throws Exception {
		throw new RuntimeException("Method not implemented");
	}
}
